package com.security.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.security.entity.User;
import com.security.service.UserService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/crud/admin")
public class UserCrudController {

	@Autowired
	private UserService service;

	 
//	@GetMapping("/getUsers")
//	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
//	public List<User> getUserData() {
//		return service.getUserData();
//	}
	
	 @GetMapping("/getUsers")
	 @PreAuthorize("hasAuthority('ROLE_ADMIN')")
	    public ResponseEntity<Page<User>> getUsers(Pageable pageable) {
		 System.out.println("pageable:-"+ pageable);
	        Page<User> users = service.getAllUsers(pageable);
	        System.out.println("Users :- "+ users);
	        return ResponseEntity.ok(users);
	    }

	@PostMapping("/insertUser")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String insertUserData(@RequestBody User user) {
		System.out.println(user);
		return service.insertUserData(user);
	}

	@GetMapping("/getUserById/{id}")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public User getUserById(@PathVariable int id) {
		 Optional<User> userById = service.getUserById(id);
		User user = userById.get();
		return user;
		 
	}

	/*
	 * @GetMapping("/getUserById") public User getUserByIdRequestParam(@RequestParam
	 * int id) { try { Optional<User> userById = service.getUserById(id); User user
	 * = userById.get(); return user; }catch (Exception e) { // TODO: handle
	 * exception e.printStackTrace(); return new User(); } }
	 */

	@DeleteMapping("/deleteById/{id}")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String deleteUserByUserId(@PathVariable int id) {
		return service.deleteUserByUserId(id);
	}

	@PutMapping("/updateUser/{id}")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public User updateUser(@PathVariable int id, @RequestBody User user) {
		return service.updateUser(user);
	}

}
