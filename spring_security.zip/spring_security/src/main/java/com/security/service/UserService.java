package com.security.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.security.entity.User;
import com.security.repository.IUser;

//import com.rest.entity.User;
//import com.rest.repository.IUser;

@Service
public class UserService {

	@Autowired
	private IUser iUser;

//	public List<User> getUserData() {
//		return iUser.findAll();
//	}
	
	 public Page<User> getAllUsers(Pageable pageable) {
	        return iUser.findAll(pageable);
	    }

	public String insertUserData(User user) {
		try {
			iUser.save(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "User Data Save succesfully";
	}

	public Optional<User> getUserById(int id) {
		return iUser.findById(id);
	}

	public String deleteUserByUserId(int id) {
		try {
			iUser.deleteById(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "User Is Deleted Successfully...!";
	}

	public User updateUser(User user) {
		User updatedUser = null;
		try {
			Optional<User> userData = iUser.findById(user.getId());

			if (userData.isPresent()) {
				User updateUser = userData.get();
				updateUser.setAddress(user.getAddress());
				updateUser.setDesignation(user.getDesignation());
				updateUser.setEmail(user.getEmail());
				updateUser.setId(user.getId());
				updateUser.setName(user.getName());
				updateUser.setPhone(user.getPhone());
				updateUser.setAge(user.getAge());

				updatedUser = iUser.save(updateUser);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return updatedUser;
	}
}
