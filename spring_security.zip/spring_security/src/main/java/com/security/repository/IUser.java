package com.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.rest.entity.User;

public interface IUser extends JpaRepository<com.security.entity.User, Integer> {

}
